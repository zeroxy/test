var express = require('express');
var router = express.Router();
var request = require('request')
var cheerio = require('cheerio');
var iconv = require('iconv-lite');
var xml2js = require('xml2js');


var xmlparser = xml2js.Parser({ explicitArray: false });
var result = [];
//var store = ["봄이온소반","헬스기빙 스페셜티","스냅스냅 김밥(T/O)","스냅스냅 착즙주스(T/O)","Take me out 샌드위치","Take me out 즉석빵","Take me out 과일","Take me out 샐러드콤보"
//,"봄이온소반","도담찌개","테이스티가든","가츠엔","싱푸차이나","스냅스낵 착즙주스(T/O)","스냅스낵 피크닉(T/O)","봄이온소반","도담찌개","고슬고슬비빈","우리미각면","헬스기빙 코리안","헬스기빙 스페셜티","브라운그릴","브라운그릴"
//,"브라운그릴","가츠엔","싱푸차이나","스냅스낵","Take me out 피크닉","Take me out 과일","Take me out 비빔","Take me out 착즙주스","봄이온소반","도담찌개","스냅스낵","헬스기빙 스페셜티","가츠엔","싱푸차이나"];

var crawl = function(){
  request({url:'http://www.welstory.com/menu/seoulrnd/weeklyMenu.jsp',encoding:null}, function (error, response, body) {
    if (!error && response.statusCode == 200) {
      var $ = cheerio.load(iconv.decode(body, 'euc-kr'), { normalizeWhitespace: true, xmlMode: true });
      var store = $('.menu_name');
      var menus = $('.menu_name2');
      var kcals = $('.Kcal_name');
      for (var i = 0; i < menus.length; i++){
        var storeNum = Math.floor(i/5);
        result[i] = {
          store:store[storeNum].children[0].data,
          storenum:storeNum,
          type:(storeNum<8)?(storeNum<2)?0:1:(storeNum<15)?-2:(storeNum<31)?2:3,
          name:menus[i].children[0].data,
          cal :kcals[i].children.length?parseInt(kcals[i].children[0].data):-1
          };
      }
      console.log("crawling complete",new Date());
    } else {
      console.log(error);
    }
  })
};
crawl();
router.get('/json', function(req, res, next) {
  var reqtime = new Date(req._startTime.getTime() + (req._startTime.getTimezoneOffset() * 60000) + (9 * 3600000));
  var tmpdate = reqtime.getDay() - 1;
  var tmpmenu = [];
  for (; tmpdate < result.length; tmpdate+=5){
    if ( result[tmpdate].cal != -1 ){ tmpmenu.push(result[tmpdate]); }
  }
  
  var time = reqtime.getHours()*100+reqtime.getMinutes();
  var availmenu = tmpmenu.filter(function(el){
         if (                  time <=  820   && (el.type == 0 || el.type == 1) ){ return true; }
    else if ( ( time >= 820 && time <=  920 ) && (el.type == 1 || el.type == 2) ){ return true; }
    else if ( ( time >= 920 && time <= 1300 ) && (el.type == 2                ) ){ return true; }
    else if ( ( time >=1300 && time <= 1900 ) && (el.type == 3                ) ){ return true; }
    return false;
  });
  res.send({avail:availmenu, today:tmpmenu});
  //res.send({avail:availmenu, today:tmpmenu, full:result});
});
router.get('/refresh', function(req, res, next) {
  crawl();
  res.send();
});




var buscrawl = function(cb){
  var baseurl = 'http://bus.go.kr/xmlRequest/getStationByUid.jsp?strBusNumber='
  var stationList = ['22667'];//,'22955','22424','22774','22284'];
  
  var finallyresult = stationList.map(function(el){
    //console.log(baseurl+el);
    request({url:baseurl+el},function(error, response, body){
      if(error){
        return '';
      }
      //console.log(response, body);
      xmlparser.parseString(body, function (err, result){
        //console.log('',result);
        var data = JSON.stringify(result);
        //console.log("",data);
        cb(data);
        return data;
        //xml = xmlbuilder.buildObject(result);
        //console.log(xml);
        
      });
    })
  });
}
buscrawl(console.log);

//http://bus.go.kr/xmlRequest/getStationByUid.jsp?strBusNumber=22424
//http://bus.go.kr/xmlRequest/getStationByUid.jsp?strBusNumber=22283


//선바위역 실시간 - http://bus.go.kr/getSubway_6.jsp?statnId=1004000435&subwayId=1004

//선바위역 운영계획 http://bus.go.kr/getSubway_6.jsp?statnId=1004000435&subwayId=1004&tabmn=5

module.exports = router;
